package com.daniel.aura

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object DanielTheme {
    val BG = Color.parseColor("#0B1020")
    val SURFACE = Color.parseColor("#151B30")
    val SURFACE_HI = Color.parseColor("#1D2540")
    val STROKE = Color.parseColor("#262F4D")
    val ACCENT = Color.parseColor("#7C5CFF")
    val TEXT = Color.parseColor("#E8ECF7")
    val MUTED = Color.parseColor("#8B93AD")
    val OK = Color.parseColor("#34D399")
}

/**
 * Interface moderne de Daniel — Aura IA.
 * Utilisation dans MainActivity : voir LISEZMOI.md
 */
class DanielUi(private val ctx: Context, private val actions: Actions) {

    interface Actions {
        fun onSend(text: String)
        fun onSpeak()
        fun onFloating()
        fun onSystem()
        fun onVoiceConfig()
        fun onWebsite()
    }

    val root: LinearLayout
    private val chatList: LinearLayout
    private val scroll: ScrollView
    private val input: EditText
    private val statusText: TextView
    private val statusDot: View
    private var thinkingBubble: View? = null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun box(color: Int, radiusDp: Int, strokeColor: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    init {
        root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(DanielTheme.BG)
            fitsSystemWindows = true
        }

        // En-tête : logo + titre + statut
        val logo = TextView(ctx).apply {
            text = "D"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = circle(DanielTheme.ACCENT)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        val title = TextView(ctx).apply {
            text = "Daniel"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(DanielTheme.TEXT)
        }
        statusDot = View(ctx).apply {
            background = circle(DanielTheme.OK)
            layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(6) }
        }
        statusText = TextView(ctx).apply {
            text = "Assistant prêt"
            textSize = 12f
            setTextColor(DanielTheme.MUTED)
        }
        val statusRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(statusDot)
            addView(statusText)
        }
        val titleBlock = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(title)
            addView(statusRow)
        }
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
            addView(logo)
            addView(titleBlock)
        }
        root.addView(header)

        // Raccourcis (puces défilantes)
        val chips = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(4), dp(16), dp(8))
            addView(chip("Bouton flottant") { actions.onFloating() })
            addView(chip("Actions système") { actions.onSystem() })
            addView(chip("Voix de Daniel") { actions.onVoiceConfig() })
            addView(chip("Site web") { actions.onWebsite() })
        }
        root.addView(HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        })

        // Zone de discussion
        chatList = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        scroll = ScrollView(ctx).apply {
            isFillViewport = true
            addView(chatList)
        }
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Barre de saisie
        input = EditText(ctx).apply {
            hint = "Pose ta question à Daniel…"
            setHintTextColor(DanielTheme.MUTED)
            setTextColor(DanielTheme.TEXT)
            textSize = 15f
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            maxLines = 4
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false
            }
        }
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = box(DanielTheme.SURFACE, 28, DanielTheme.STROKE)
            setPadding(dp(18), dp(6), dp(6), dp(6))
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(roundButton(android.R.drawable.ic_btn_speak_now, DanielTheme.SURFACE_HI, "Parler") { actions.onSpeak() })
            addView(roundButton(android.R.drawable.ic_menu_send, DanielTheme.ACCENT, "Envoyer") { send() })
        }
        root.addView(bar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(12), dp(8), dp(12), dp(12))
        })

        addMessage("Bonjour, je suis Daniel. Pose ta question par écrit ou par la voix.", false)
    }

    private fun chip(label: String, onClick: () -> Unit) = TextView(ctx).apply {
        text = label
        textSize = 13f
        setTextColor(DanielTheme.TEXT)
        background = box(DanielTheme.SURFACE, 18, DanielTheme.STROKE)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { rightMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun roundButton(icon: Int, bg: Int, desc: String, onClick: () -> Unit) =
        ImageView(ctx).apply {
            setImageResource(icon)
            setColorFilter(Color.WHITE)
            background = circle(bg)
            contentDescription = desc
            setPadding(dp(9), dp(9), dp(9), dp(9))
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(6) }
            setOnClickListener { onClick() }
        }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        actions.onSend(t)
    }

    /** Ajoute une bulle de discussion. */
    fun addMessage(text: String, fromUser: Boolean): View {
        val bubble = TextView(ctx).apply {
            this.text = text
            textSize = 15f
            setLineSpacing(0f, 1.15f)
            maxWidth = (ctx.resources.displayMetrics.widthPixels * 0.78f).toInt()
            setPadding(dp(14), dp(10), dp(14), dp(10))
            if (fromUser) {
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(DanielTheme.ACCENT)
                    val r = dp(18).toFloat(); val s = dp(4).toFloat()
                    cornerRadii = floatArrayOf(r, r, s, s, r, r, r, r)
                }
            } else {
                setTextColor(DanielTheme.TEXT)
                background = GradientDrawable().apply {
                    setColor(DanielTheme.SURFACE)
                    setStroke(dp(1), DanielTheme.STROKE)
                    val r = dp(18).toFloat(); val s = dp(4).toFloat()
                    cornerRadii = floatArrayOf(s, s, r, r, r, r, r, r)
                }
            }
        }
        chatList.addView(bubble, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            bottomMargin = dp(10)
        })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return bubble
    }

    /** Affiche ou masque « Daniel réfléchit… ». */
    fun setThinking(on: Boolean) {
        thinkingBubble?.let { chatList.removeView(it) }
        thinkingBubble = if (on) addMessage("Daniel réfléchit…", false).also {
            (it as TextView).setTextColor(DanielTheme.MUTED)
        } else null
        setStatus(if (on) "Daniel réfléchit…" else "Assistant prêt")
    }

    fun setStatus(text: String) { statusText.text = text }
}
