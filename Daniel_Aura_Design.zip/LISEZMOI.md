# Daniel — Aura IA : nouveau design

Contenu
- app/src/main/java/com/daniel/aura/DanielUi.kt  (toute l'interface, sans dépendance)
- app/src/main/res/values/themes.xml              (barres système sombres)

Intégration dans MainActivity.kt
1. Copiez les deux fichiers dans votre projet (même chemins).
2. Dans AndroidManifest.xml : android:theme="@style/Theme.DanielAura" sur <application>.
3. Remplacez le contenu de buildUi() par :

    private lateinit var ui: DanielUi

    private fun buildUi() {
        ui = DanielUi(this, object : DanielUi.Actions {
            override fun onSend(text: String) = sendMessage(text)   // adaptez au nom/signature réels
            override fun onSpeak() = startVoiceInput()
            override fun onFloating() = enableOverlay()
            override fun onSystem() = startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            override fun onVoiceConfig() = configureVoice()
            override fun onWebsite() = startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://danielservice225-dot.github.io/Daniel/")))
        })
        setContentView(ui.root)
    }

4. Dans sendMessage() et le reste du code, remplacez l'ajout de texte dans l'ancien
   TextView de discussion par :
     ui.addMessage("Texte", true)    // message de l'utilisateur
     ui.addMessage("Texte", false)   // réponse de Daniel
     ui.setThinking(true) avant l'appel réseau, ui.setThinking(false) à la réponse
     ui.setStatus("...") pour la ligne d'état

Couleurs : modifiez DanielTheme (en haut de DanielUi.kt) pour changer l'accent.
